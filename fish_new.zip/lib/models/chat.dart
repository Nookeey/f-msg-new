import 'package:flutter/material.dart';

class Chat {
  final String id;
  final String image;
  final String name;
  final String message;

  Chat({
    @required this.id,
    @required this.image,
    @required this.name,
    @required this.message
  });
}
