import 'package:flutter/foundation.dart';

// import '../models/message.dart';

class MessageProvider with ChangeNotifier {

}
