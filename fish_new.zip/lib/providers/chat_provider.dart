import 'package:flutter/foundation.dart';

// import '../models/chat.dart';

class ChatProvider with ChangeNotifier {

}
