import 'package:flutter/material.dart';

class FishDetailScreen extends StatelessWidget {
  static const routeName = '/fish_details';

  @override
  Widget build(BuildContext context) {
    return null;
  }
}